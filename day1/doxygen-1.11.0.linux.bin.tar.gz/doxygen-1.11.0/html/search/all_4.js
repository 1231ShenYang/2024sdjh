var searchData=
[
  ['3_0',['3',['../changelog.html#log_1_8_3',1,'Release 1.8.3'],['../changelog.html#log_1_9_3',1,'Release 1.9.3']]],
  ['3_201_1',['Release 1.8.3.1',['../changelog.html#log_1_8_3_1',1,'']]],
  ['3_20series_2',['1.3 Series',['../changelog.html#log_1_3',1,'']]],
  ['3_3a_20documenting_20the_20sources_3',['Step 3: Documenting the sources',['../starting.html#step3',1,'']]]
];
