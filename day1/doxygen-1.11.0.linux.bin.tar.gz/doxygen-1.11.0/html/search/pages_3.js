var searchData=
[
  ['emoji_20support_0',['Emoji support',['../emojisup.html',1,'']]],
  ['external_20documentation_1',['Linking to external documentation',['../external.html',1,'']]],
  ['external_20indexing_20and_20searching_2',['External Indexing and Searching',['../extsearch.html',1,'searching']]]
];
