var searchData=
[
  ['s_20internals_0',['Doxygen&apos;s Internals',['../arch.html',1,'']]],
  ['searching_1',['Searching',['../extsearch.html',1,'External Indexing and Searching'],['../searching.html',1,'Searching']]],
  ['special_20commands_2',['Special Commands',['../commands.html',1,'']]],
  ['started_3',['Getting started',['../starting.html',1,'']]],
  ['support_4',['support',['../emojisup.html',1,'Emoji support'],['../markdown.html',1,'Markdown support']]]
];
