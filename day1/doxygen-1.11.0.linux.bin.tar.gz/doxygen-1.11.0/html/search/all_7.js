var searchData=
[
  ['6_0',['6',['../changelog.html#log_1_8_6',1,'Release 1.8.6'],['../changelog.html#log_1_9_6',1,'Release 1.9.6']]],
  ['6_20series_1',['1.6 Series',['../changelog.html#log_1_6',1,'']]]
];
